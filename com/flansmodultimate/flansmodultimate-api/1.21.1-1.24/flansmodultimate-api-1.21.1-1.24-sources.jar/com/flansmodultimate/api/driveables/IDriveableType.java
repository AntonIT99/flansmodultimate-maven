/*
 * Copyright (c) 2026 Wolff (AntonIT99)
 * SPDX-License-Identifier: MIT
 * See LICENSE-API at the root of the Flan's Mod Ultimate repository.
 */
package com.flansmodultimate.api.driveables;

import com.flansmodultimate.api.content.IContentType;
import com.flansmodultimate.api.parts.PartArmor;
import org.jetbrains.annotations.ApiStatus;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

/**
 * A content-pack driveable definition: a vehicle, plane or mecha.
 *
 * <p>
 * Distances are in blocks, in the driveable's local frame before it is rotated, with the
 * origin at the driveable entity's position and Y up. Horizontally, X is the lateral axis and Z
 * the longitudinal (fore-aft) one. Which end of Z is the front differs between planes and other
 * driveables, so rely on extents rather than on signs.
 * </p>
 */
@ApiStatus.Experimental
@ApiStatus.NonExtendable
public interface IDriveableType extends IContentType
{
    DriveableKind getDriveableKind();

    /**
     * Whether firing the selected bank starts the main barrel's recoil stroke. Readable on either side after content loading.
     * This describes weapon animation, independently of camera shake and the authored recoil duration.
     *
     * @param secondary
     *            true for the secondary weapon bank, false for the primary bank
     * @return whether the bank fires shells
     */
    default boolean hasBarrelRecoil(boolean secondary)
    {
        return false;
    }

    /**
     * Whether a weapon bank uses gun or shell cartridges, rather than rockets, missiles or dropped ordnance.
     * Readable on either side after content loading; individual mounted gun definitions may refine ejection behavior.
     *
     * @param secondary
     *            true for the secondary weapon bank, false for the primary bank
     * @return whether cosmetic cartridge ejection is suitable for the bank
     */
    default boolean hasCartridgeEjection(boolean secondary)
    {
        return false;
    }

    /** @return the definition's model and part scale; readable on either side after content loading */
    @SuppressWarnings("SameReturnValue") // Compatibility default; driveable definitions override this with their authored scale.
    default float getModelScale()
    {
        return 1F;
    }

    /**
     * Reads an authored plate without simulating a hit. Either side after content loading; no world access.
     *
     * @param part
     *            legacy part name, case insensitive
     * @param outwardNormal
     *            direction toward the observer in the part's semantic frame: front is -Z, right +X and roof +Y
     * @return nominal kinetic and HEAT protection in millimetres on the dominant face, or empty for unknown parts or
     *         unauthored protection. Does not include slope, impact angle, distance, or live entity overrides
     */
    default Optional<PartArmor> getPartArmor(String part, Vec3 outwardNormal)
    {
        return Optional.empty();
    }

    /**
     * Minimum incoming melee damage in health points, before armour and resistances. Weaker hits are ignored;
     * hits at the threshold apply in full. Zero accepts every hit. Includes the server default when no pack override
     * is authored. Readable on either side after content loading and config synchronization.
     *
     * @return the effective melee threshold
     */
    default float getMeleeDamageThreshold()
    {
        return 10F;
    }

    /**
     * Returns the ship classification used by creative inventory and model browsers.
     * Water-only hulls and explicitly marked ships qualify; amphibious ground vehicles
     * and seaplanes with flight controls do not. Safe to query on either side.
     *
     * @return whether this definition represents a ship, independently of its underlying entity kind
     */
    default boolean isShip()
    {
        return false;
    }

    /**
     * @return whether the driveable runs on tracks and can turn on the spot, as a tank does
     */
    default boolean isTracked()
    {
        return false;
    }

    /**
     * @return whether the driveable is a plane that flies as a helicopter: it hovers and climbs on its rotors rather
     *         than its wings
     */
    default boolean isHelicopter()
    {
        return false;
    }

    /**
     * @return the height of the origin above level ground when the driveable rests on its wheels,
     *         as its suspension places it, or its {@code YOffset} when it has no wheels. Negative
     *         when the wheels sit above the origin, as with some flying boats.
     */
    float getRestingHeight();

    /**
     * @return the height of the origin above the water surface when the driveable floats at rest, as its draft or its
     *         wheel anchors and {@code FloatOffset} place it; its resting height when it does not float
     */
    default float getFloatingHeight()
    {
        return getRestingHeight();
    }

    /**
     * @return the collision box of the core part, which is the main body, if the definition has one
     */
    Optional<AABB> getCoreBounds();

    /**
     * @return the box enclosing the collision boxes of every part, if the definition has any
     */
    Optional<AABB> getBounds();
}
