/*
 * Copyright (c) 2026 Wolff (AntonIT99)
 * SPDX-License-Identifier: MIT
 * See LICENSE-API at the root of the Flan's Mod Ultimate repository.
 */
package com.flansmodultimate.api.teams;

import com.flansmodultimate.common.block.entity.TeamSpawnerBlockEntity;
import com.flansmodultimate.common.teams.TeamsCombatants;
import com.flansmodultimate.common.teams.TeamsDeathDrops;
import com.flansmodultimate.common.teams.TeamsListeners;
import com.flansmodultimate.common.teams.TeamsManager;
import com.flansmodultimate.common.teams.TeamsShipSpawns;
import com.flansmodultimate.common.types.Team;
import org.jetbrains.annotations.ApiStatus;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;

/**
 * Entry point to the Teams game modes for addons: the rotation, the round being played, the events of a round, and
 * combatants, the non-player entities that fight for a team.
 *
 * <p>
 * A combatant counts for its team as a player does for as long as the round it was assigned in is played: it is
 * spared by its allies unless the game type allows friendly fire, it stands on capture points with its capture weight,
 * its kills score for its team and its deaths are scored like a player's. The assignment is saved with the entity and
 * lapses by itself when that round ends.
 * </p>
 *
 * <p>
 * Every method is for the server thread. Elsewhere, or without a running server, queries return nothing and changes
 * are refused.
 * </p>
 */
@ApiStatus.Experimental
public final class FlansTeams
{
    private FlansTeams()
    {}

    /**
     * Checks the live shared cooldown of a loaded vehicle spawner. A snapshot alone does not track readiness.
     * This checks only the cooldown; addons must also validate ownership, NPC permissions and placement.
     * Server thread only.
     *
     * @param spawner
     *            the spawner snapshot to resolve
     * @return false off the server thread, for an unavailable plate, or while its cooldown runs
     */
    public static boolean isVehicleSpawnerReady(TeamsSpawner spawner)
    {
        return vehicleSpawner(spawner).map(TeamSpawnerBlockEntity::isSpawnReady).orElse(false);
    }

    /**
     * Starts a vehicle spawner's shared cooldown after an addon successfully deploys a vehicle from it.
     * Call immediately after creating the entity on the server thread. Failed attempts must not call this.
     *
     * @param spawner
     *            the spawner snapshot used for deployment
     */
    public static void recordVehicleSpawnerSpawn(TeamsSpawner spawner)
    {
        vehicleSpawner(spawner).ifPresent(TeamSpawnerBlockEntity::recordSpawn);
    }

    private static Optional<TeamSpawnerBlockEntity> vehicleSpawner(TeamsSpawner spawner)
    {
        return manager().flatMap(manager -> manager.getObject(spawner.id())).filter(TeamSpawnerBlockEntity.class::isInstance).map(TeamSpawnerBlockEntity.class::cast)
            .filter(plate -> plate.getMode() == TeamSpawnerBlockEntity.Mode.VEHICLE && !plate.isRemoved() && plate.getDimension().equals(spawner.dimension())
                && plate.getBlockPos().equals(spawner.position()));
    }

    /**
     * Finds the nearest clear water surface for a Teams ship or ship bot, at most 64 blocks from the requested
     * position in three dimensions. Searches loaded chunks only, including underground water. The result is the
     * bottom centre of the block above water; callers apply their model's placement offset. Server thread only.
     *
     * @param level
     *            server level in which to spawn
     * @param origin
     *            requested spawn position, in blocks
     * @return a water surface position, or empty when none is available; callers must postpone spawning when empty
     */
    public static Optional<Vec3> findShipSpawn(ServerLevel level, Vec3 origin)
    {
        return TeamsShipSpawns.find(level, origin);
    }

    /**
     * @return the round being played, or empty between rounds and while Teams is disabled
     */
    public static Optional<ITeamsLiveRound> getRunningRound()
    {
        return manager().flatMap(manager -> manager.getLiveRound().map(ITeamsLiveRound.class::cast));
    }

    /**
     * Whether Teams replaces this entity's native passive healing with the round regeneration rule.
     * Addons should skip their automatic regeneration when true, including when the rule is off.
     * Medical items, effects and repairs remain independent. Server thread only.
     *
     * @param entity
     *            living entity to check
     * @return whether the round owns its passive regeneration
     */
    public static boolean usesRoundRegeneration(LivingEntity entity)
    {
        return manager().isPresent() && com.flansmodultimate.common.teams.TeamsRegeneration.applies(entity);
    }

    /**
     * Applies the server's global bot maximum-health override, including between rounds, preserving the remaining health
     * percentage. Call after updating an addon's own health attributes, and when bot membership changes. The modifier is
     * saved with the entity so health survives loading; passing false removes it and restores the entity's own maximum.
     * Does nothing off the server thread or without a running server.
     *
     * @param entity
     *            an addon's living bot or former bot
     * @param bot
     *            whether the entity currently belongs to the addon's bot forces
     */
    public static void applyBotHealthOverride(LivingEntity entity, boolean bot)
    {
        manager().ifPresent(manager -> com.flansmodultimate.common.teams.TeamsHealth.apply(entity, bot ? manager.getBotHealth() : 0));
    }

    /**
     * How long the bodies of an addon's fallen bots stay after their death animation, by the Teams {@code corpses} and
     * {@code corpseLife} rules. A corpse kept until the round ends should be removed with the round's other bots. Server
     * thread only.
     *
     * @return the seconds a corpse stays, 0 to keep it until the round ends, or empty when the rule is off or off the
     *         server thread
     */
    public static OptionalInt getBotCorpseLife()
    {
        return manager().filter(TeamsManager::isCorpses).map(manager -> OptionalInt.of(manager.getCorpseLife())).orElse(OptionalInt.empty());
    }

    /**
     * @return the entries of the rotation in their order, immutable
     */
    public static List<ITeamsRound> getRounds()
    {
        return manager().map(manager -> List.<ITeamsRound>copyOf(manager.getRounds())).orElse(List.of());
    }

    /**
     * Saves data of an addon with a rotation entry, under the addon's own key; it is kept with the rotation.
     *
     * @param round
     *            an entry of the rotation
     * @param key
     *            the addon's key, namespaced with its mod id
     * @param data
     *            the data to keep, copied; an empty tag removes the key
     * @return whether the entry is in the rotation and the data was saved
     */
    public static boolean setRoundExtensionData(ITeamsRound round, ResourceLocation key, CompoundTag data)
    {
        return manager().map(manager -> manager.setRoundExtensionData(round, key, data)).orElse(false);
    }

    /**
     * @param entity
     *            any entity
     * @return the team the entity fights for in the round being played: a player's team, or a combatant's. Empty for
     *         spectators, for players and entities taking no part, and between rounds.
     */
    public static Optional<ITeam> getTeam(Entity entity)
    {
        return manager().map(manager -> TeamsCombatants.getPlayingTeam(manager, entity));
    }

    /**
     * Makes a living entity fight for a team in the round being played, as a player of that team would.
     *
     * @param entity
     *            any living entity but a player, which joins teams through the team menu
     * @param team
     *            a team of the running round
     * @param captureWeight
     *            how much the entity counts on a capture point, where a player counts 1; 0 keeps it off the points
     * @return whether the entity is now a combatant of that team; false when no round runs, the team does not play
     *         it or the weight is negative or not finite
     */
    public static boolean assignCombatant(LivingEntity entity, ITeam team, float captureWeight)
    {
        return !(entity instanceof Player) && team instanceof Team internal && manager().map(manager -> TeamsCombatants.assign(manager, entity, internal, captureWeight)).orElse(false);
    }

    /**
     * Makes a living entity fight for a team in the round being played, counting as one player on capture points.
     *
     * @see #assignCombatant(LivingEntity, ITeam, float)
     */
    public static boolean assignCombatant(LivingEntity entity, ITeam team)
    {
        return assignCombatant(entity, team, 1F);
    }

    /**
     * Takes an entity out of the round; nothing happens to one that is not a combatant.
     *
     * @param entity
     *            a combatant
     */
    public static void releaseCombatant(LivingEntity entity)
    {
        if (manager().isPresent())
            TeamsCombatants.release(entity);
    }

    /**
     * Applies the server's Teams {@code weaponDrops} and {@code armourDrops} rules to what a dying addon combatant drops, as
     * they apply to a dying player: with weapon drops off its guns, driveables and rounds are removed, and with smart drops
     * each gun type drops once as a bundle carrying the matching ammunition. Server thread, from the entity's
     * {@code LivingDropsEvent}.
     *
     * @param drops
     *            the drops of that event, changed in place
     */
    public static void applyDeathDropRules(Collection<ItemEntity> drops)
    {
        manager().ifPresent(manager -> TeamsDeathDrops.apply(manager, drops));
    }

    /**
     * @return whether the entity is a combatant of the round being played; players never are
     */
    public static boolean isCombatant(Entity entity)
    {
        return manager().map(manager -> TeamsCombatants.getCombatantTeam(manager, entity) != null).orElse(false);
    }

    /**
     * @return how much the entity counts on a capture point: 1 for a playing player, a combatant's capture weight, and
     *         0 for anyone else
     */
    public static float getCaptureWeight(Entity entity)
    {
        return manager().map(manager -> TeamsCombatants.getCaptureWeight(manager, entity)).orElse(0F);
    }

    /**
     * @return whether both entities play the running round, players or combatants, on opposite sides
     */
    public static boolean areEnemies(Entity first, Entity second)
    {
        return manager().map(manager -> TeamsCombatants.areEnemies(manager, first, second)).orElse(false);
    }

    /**
     * Whether the round being played lets one of its fighters hurt another, as its game type rules: enemies always, allies
     * only while the game type's friendly fire variable is on.
     *
     * @param victim
     *            the entity that would be hurt
     * @param attacker
     *            the entity responsible for the hit
     * @return whether the hit may land; empty unless both play the running round, players or combatants, so that the round
     *         does not judge it
     */
    public static Optional<Boolean> mayHarm(LivingEntity victim, LivingEntity attacker)
    {
        return manager().flatMap(manager -> TeamsCombatants.mayHarm(manager, victim, attacker));
    }

    /**
     * Ends the round being played at once, with the side of {@code winner} as the winner, as when a game type decides
     * it: the end-of-round event, scores and the break that follows all run as usual. For rules an addon adds, such as
     * a side running out of reinforcements it manages.
     *
     * @param winner
     *            a team of the running round; its allies win with it
     * @return whether a round was running with that team and has now ended
     */
    public static boolean declareWinner(ITeam winner)
    {
        return winner instanceof Team internal && manager().map(manager -> manager.declareWinner(internal)).orElse(false);
    }

    /**
     * Sets the rows an addon shows for a team on the scoreboard of the round being played, beside the team's players.
     * They replace the rows set before and are dropped when the round ends. Clients receive them with the next
     * scoreboard update, every two seconds.
     *
     * @param team
     *            a team of the running round
     * @param entries
     *            the rows, copied; empty removes them
     * @return whether a round was running with that team
     */
    public static boolean setScoreboardEntries(ITeam team, List<TeamsScoreEntry> entries)
    {
        return team instanceof Team internal && manager().map(manager -> manager.setScoreboardEntries(internal, entries)).orElse(false);
    }

    /**
     * Registers a listener for Teams events. Registering the same listener twice has no effect.
     */
    public static void addListener(ITeamsListener listener)
    {
        TeamsListeners.add(listener);
    }

    public static void removeListener(ITeamsListener listener)
    {
        TeamsListeners.remove(listener);
    }

    /**
     * Registers a rule that may keep players from taking the field again, such as a ticket limit. Registering the same rule
     * twice has no effect.
     */
    public static void addRespawnRule(ITeamsRespawnRule rule)
    {
        TeamsListeners.addRespawnRule(rule);
    }

    public static void removeRespawnRule(ITeamsRespawnRule rule)
    {
        TeamsListeners.removeRespawnRule(rule);
    }

    /**
     * Registers a provider of spawn positions, such as squads or rally points players may spawn on. Registering the same
     * provider twice has no effect.
     */
    public static void addSpawnProvider(ITeamsSpawnProvider provider)
    {
        TeamsListeners.addSpawnProvider(provider);
    }

    public static void removeSpawnProvider(ITeamsSpawnProvider provider)
    {
        TeamsListeners.removeSpawnProvider(provider);
    }

    private static Optional<TeamsManager> manager()
    {
        TeamsManager manager = TeamsManager.getInstance();
        return manager.isServerThread() ? Optional.of(manager) : Optional.empty();
    }
}
