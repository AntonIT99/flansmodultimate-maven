/*
 * Copyright (c) 2026 Wolff (AntonIT99)
 * SPDX-License-Identifier: MIT
 * See LICENSE-API at the root of the Flan's Mod Ultimate repository.
 */
package com.flansmodultimate.api.projectiles;

import com.flansmodultimate.api.content.IContentType;
import com.flansmodultimate.api.driveables.MountAim;
import com.flansmodultimate.api.driveables.ReloadCycle;
import com.flansmodultimate.api.driveables.WeaponMount;
import com.flansmodultimate.api.driveables.WeaponMuzzle;
import com.flansmodultimate.api.entity.ISuppressionListener;
import com.flansmodultimate.common.guns.ArmorImpactHandler;
import com.flansmodultimate.common.guns.ExternalProjectileSupport;
import com.flansmodultimate.common.guns.NearMissHandler;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

/** Projectile and weapon presentation support for addon-controlled living entities. */
@ApiStatus.Experimental
public final class FlansProjectiles
{
    private FlansProjectiles()
    {}

    /**
     * Registers a listener for Flan rounds that pass close to mobs, so NPCs can react to being shot at. Registering the
     * same listener twice has no effect.
     */
    public static void addSuppressionListener(ISuppressionListener listener)
    {
        NearMissHandler.addListener(listener);
    }

    public static void removeSuppressionListener(ISuppressionListener listener)
    {
        NearMissHandler.removeListener(listener);
    }

    /** Registers a server armour-impact listener; repeated registration of the same instance has no effect. */
    public static void addArmorImpactListener(IArmorImpactListener listener)
    {
        ArmorImpactHandler.addListener(listener);
    }

    /** Removes a previously registered armour-impact listener. */
    public static void removeArmorImpactListener(IArmorImpactListener listener)
    {
        ArmorImpactHandler.removeListener(listener);
    }

    /** @return whether the stack represents a Flan bullet or grenade; readable on either side */
    public static boolean isProjectile(ItemStack stack)
    {
        return ExternalProjectileSupport.isProjectile(stack);
    }

    /**
     * Tests whether Flan ammunition has any usable rounds, including subsequent items in a stacked magazine. Readable on
     * either side without changing the stack. Unlike {@link #isProjectile(ItemStack)}, this rejects exhausted magazines.
     *
     * @param stack
     *            ammunition to inspect
     * @return whether at least one round remains; false for another item or an empty stack
     */
    public static boolean hasRoundsLeft(ItemStack stack)
    {
        return ExternalProjectileSupport.hasRoundsLeft(stack);
    }

    /** @return whether the stack represents a Flan grenade; readable on either side */
    public static boolean isGrenade(ItemStack stack)
    {
        return ExternalProjectileSupport.isGrenade(stack);
    }

    /**
     * Reads a grenade's purpose and additional effect reach from its definition, without changing the stack.
     * Readable on either side after content loading.
     *
     * @param stack
     *            item to inspect
     * @return grenade properties, or empty for another item
     */
    public static Optional<GrenadeProperties> getGrenadeProperties(ItemStack stack)
    {
        return ExternalProjectileSupport.grenadeProperties(stack);
    }

    /** @return the rounds one item of this Flan ammunition holds when full, or zero for another item; readable on either side */
    public static int getRoundsPerItem(ItemStack stack)
    {
        return ExternalProjectileSupport.roundsPerItem(stack);
    }

    /**
     * Reads how far the round reaches round its point of detonation, so that a shooter can keep clear of it. The radii follow
     * the server's current explosion settings. Readable on either side after content loading.
     *
     * @return the radii of a Flan bullet or grenade, or empty for another item
     */
    public static Optional<DetonationRadii> getDetonationRadii(ItemStack stack)
    {
        return ExternalProjectileSupport.detonationRadii(stack);
    }

    /**
     * Inspects a bullet or a round of a mixed belt. Either side after content loading; does not change the stack.
     *
     * @param ammunition
     *            ammunition stack to inspect
     * @param sequence
     *            zero-based shot index, selecting a round of a mixed belt
     * @return nominal armour performance, or empty for items without bullet statistics
     */
    public static Optional<AmmunitionArmor> getArmorPerformance(ItemStack ammunition, int sequence)
    {
        return ExternalProjectileSupport.armorPerformance(ammunition, sequence);
    }

    /**
     * Reads a belt round's nominal performance including mounted weapon and fallback platform overrides, on either side after loading.
     *
     * @param ammunition
     *            ammunition stack to inspect
     * @param sequence
     *            zero-based belt position
     * @param weapon
     *            mounted weapon, or null for the platform alone
     * @param platform
     *            carrying model, or null when absent
     * @return performance, or empty for unsupported ammunition
     */
    public static Optional<AmmunitionArmor> getArmorPerformance(ItemStack ammunition, int sequence, @Nullable IContentType weapon, @Nullable IContentType platform)
    {
        return ExternalProjectileSupport.armorPerformance(ammunition, sequence, weapon, platform);
    }

    /**
     * Uses up one round of Flan ammunition the shooter fired without a gun: one item, or one round of an item that holds
     * several. A stack left empty is the caller's to remove from where it is kept. Server thread.
     *
     * @return whether a round was used up; false for an empty stack or another item
     */
    public static boolean consumeRound(ItemStack stack)
    {
        return ExternalProjectileSupport.consumeRound(stack);
    }

    /**
     * Describes which caller defaults are replaced, without preparing or spawning a projectile.
     * Readable on either side after content loading, including for an editor preview.
     *
     * @param ammunition
     *            bullet or grenade template
     * @param heldWeapon
     *            held gun with attachments, or an empty stack
     * @param weapon
     *            mounted gun, or null to use the platform, held gun or ammunition
     * @param platform
     *            optional platform and its fallback ammunition overrides
     * @param secondary
     *            selected platform bank
     * @param weaponStats
     *            whether content weapon statistics take precedence
     * @return setting sources, or empty for unsupported ammunition
     */
    public static Optional<ProjectileSources> getSources(ItemStack ammunition, ItemStack heldWeapon, @Nullable IContentType weapon, @Nullable IContentType platform, boolean secondary,
        boolean weaponStats)
    {
        return ExternalProjectileSupport.getSources(ammunition, heldWeapon, weapon, platform, secondary, weaponStats);
    }

    /**
     * Reads the velocity a round leaves the weapon at, as {@link #prepare} resolves it with content weapon statistics:
     * the ammunition's own velocity, else the weapon's, else the default every Flan bullet falls back to. Belt rounds are
     * read at their first position. Either side after content loading, for an editor preview as well.
     *
     * @param ammunition
     *            bullet or grenade template
     * @param weapon
     *            mounted gun definition; null uses the platform or the ammunition alone
     * @param platform
     *            platform definition, including its fallback ammunition overrides, or null
     * @param secondary
     *            whether platform weapon statistics come from its secondary bank
     * @return the velocity in blocks per tick, or empty for another item
     */
    public static OptionalDouble getMuzzleVelocity(ItemStack ammunition, @Nullable IContentType weapon, @Nullable IContentType platform, boolean secondary)
    {
        return ExternalProjectileSupport.muzzleVelocity(ammunition, weapon, platform, secondary);
    }

    /**
     * Resolves one round on the server thread. Ammunition physics and effects retain their content definitions.
     *
     * @param shooter
     *            owner and damage credit; its level owns the projectile
     * @param ammunition
     *            bullet or grenade item, used as a template without consumption
     * @param heldWeapon
     *            gun with attachments, or an empty stack
     * @param weapon
     *            mounted gun definition; null uses the platform, held gun or ammunition alone
     * @param platform
     *            platform definition, including its fallback ammunition overrides, or null
     * @param secondary
     *            whether platform weapon statistics come from its secondary bank
     * @param parameters
     *            belt position, weapon-statistics switch and fallback statistics
     * @return resolved shot, or empty for unsupported ammunition, invalid values or a nonserver caller
     */
    public static Optional<ProjectileShot> prepare(LivingEntity shooter, ItemStack ammunition, ItemStack heldWeapon, @Nullable IContentType weapon, @Nullable IContentType platform, boolean secondary,
        ProjectileParameters parameters)
    {
        return ExternalProjectileSupport.prepare(shooter, ammunition, heldWeapon, weapon, platform, secondary, parameters);
    }

    /**
     * Selects the muzzles used by a static AA or driveable model, without creating a driveable entity.
     *
     * @param model
     *            model definition
     * @param secondary
     *            selected weapon bank
     * @param sequence
     *            trigger index, used to alternate points and individual barrels
     * @param alternate
     *            whether authored alternating fire is honored; false fires every barrel together
     * @return immutable selected muzzles; empty when the model has no defined weapon positions
     */
    public static List<WeaponMuzzle> getMuzzles(IContentType model, boolean secondary, int sequence, boolean alternate)
    {
        return ExternalProjectileSupport.getMuzzles(model, secondary, sequence, alternate, MountAim.REST);
    }

    /**
     * Selects the muzzles of an AA or driveable model with its turret or gun aimed, without creating a driveable
     * entity. Muzzles on the turret turn round the turret origin of the definition and elevate with the gun; the
     * barrels of an AA gun turn and elevate round the gun. Muzzles fixed to the hull stay where they are. Either side.
     *
     * @param model
     *            model definition
     * @param secondary
     *            selected weapon bank
     * @param sequence
     *            trigger index, used to alternate points and individual barrels
     * @param alternate
     *            whether authored alternating fire is honored; false fires every barrel together
     * @param aim
     *            where the turret or AA gun points, relative to the hull
     * @return immutable selected muzzles, in the same frame as the unaimed ones; empty when the model has no defined
     *         weapon positions
     */
    public static List<WeaponMuzzle> getMuzzles(IContentType model, boolean secondary, int sequence, boolean alternate, MountAim aim)
    {
        return ExternalProjectileSupport.getMuzzles(model, secondary, sequence, alternate, aim);
    }

    /**
     * Selects the muzzle of a seat's own gun on a vehicle, plane or mecha model, without creating a driveable entity. A
     * twin or quad seat gun fires its barrels in turn, so the trigger index picks one. A seat on the turret is carried round
     * with the turret; the seat gun's own aim does not move the muzzle, as it rests. Either side after content loading.
     *
     * @param model
     *            vehicle, plane or mecha definition
     * @param seat
     *            seat index, as {@link WeaponMount#seat()}
     * @param sequence
     *            trigger index, used to take the barrels in turn
     * @param turretAim
     *            where the main turret points, relative to the hull; only its yaw is used
     * @return the muzzle in the frame of {@link #getMuzzles(IContentType, boolean, int, boolean, MountAim)}, naming the seat's
     *         gun and carrying the seat's shooting particles; empty for another definition or a seat without a gun
     */
    public static Optional<WeaponMuzzle> getSeatMuzzle(IContentType model, int seat, int sequence, MountAim turretAim)
    {
        return ExternalProjectileSupport.getSeatMuzzle(model, seat, sequence, turretAim, null);
    }

    /**
     * {@link #getSeatMuzzle(IContentType, int, int, MountAim)} with the seat gun aimed: the muzzle is carried round the point
     * the gun's model turns it round, as a driven driveable carries it, and the shooting particles are pitched with the gun,
     * leaving their yaw to the caller as before. A gun whose model could not be measured keeps its muzzle where it rests.
     *
     * @param seatAim
     *            where the seat gun points, relative to the hull, or to the turret for a seat on the turret, as
     *            {@link WeaponMount} aims are given
     */
    public static Optional<WeaponMuzzle> getSeatMuzzle(IContentType model, int seat, int sequence, MountAim turretAim, MountAim seatAim)
    {
        return ExternalProjectileSupport.getSeatMuzzle(model, seat, sequence, turretAim, seatAim);
    }

    /**
     * Plays the selected weapon's content-pack firing sound. Server thread only.
     *
     * @param shooter
     *            source position and dimension
     * @param weapon
     *            mounted gun or platform, or null to use the held weapon
     * @param heldWeapon
     *            gun stack whose attachments can select a silenced sound
     * @param secondary
     *            selected platform bank
     * @return whether a sound was available and sent
     */
    public static boolean playShootSound(Entity shooter, @Nullable IContentType weapon, ItemStack heldWeapon, boolean secondary)
    {
        return ExternalProjectileSupport.playShootSound(shooter, weapon, heldWeapon, secondary);
    }

    /**
     * Plays the sound an AA gun or driveable bank makes when it begins a reload, with its authored range. A bank of
     * mounted guns prefers the gun's own reload sound, as the driveable does. Server thread only.
     *
     * @param source
     *            source position and dimension
     * @param platform
     *            AA gun or driveable definition
     * @param secondary
     *            selected driveable bank; ignored for AA guns
     * @return whether a sound was declared and sent
     */
    public static boolean playReloadSound(Entity source, IContentType platform, boolean secondary)
    {
        return ExternalProjectileSupport.playReloadSound(source, platform, secondary);
    }

    /**
     * Plays a driveable main gun's chambering sound ({@code ShootReloadSound}), timed by the caller from
     * {@link ReloadCycle#chamberSoundTick()}. Server thread only.
     *
     * @param source
     *            source position and dimension
     * @param platform
     *            driveable definition
     * @return whether a sound was declared and sent
     */
    public static boolean playChamberSound(Entity source, IContentType platform)
    {
        return ExternalProjectileSupport.playChamberSound(source, platform);
    }

    /**
     * Whether a mounted muzzle declares a flash model or can use the vehicle's DefaultFlash.
     * Safe on either side after content loading; does not load client models.
     *
     * @param platform
     *            vehicle definition
     * @param muzzle
     *            fired mount, including its optional gun definition
     * @param secondary
     *            weapon bank for muzzles without a gun definition
     * @return false for unsupported or unconfigured mounts, including non-gun banks
     */
    public static boolean hasMuzzleFlash(IContentType platform, WeaponMuzzle muzzle, boolean secondary)
    {
        return ExternalProjectileSupport.hasMuzzleFlash(platform, muzzle, secondary);
    }

    /**
     * Broadcasts authored shooting particles, with a small muzzle flame when none are declared.
     * Server thread only; clients create the particles.
     *
     * @param shooter
     *            dimension and nearby recipients
     * @param muzzle
     *            selected muzzle's particles
     * @param origin
     *            world muzzle position in blocks
     * @param bodyYaw
     *            vanilla entity yaw in degrees, rotating the model's -Z facing into world space
     * @param scale
     *            particle size and velocity multiplier
     */
    public static void shootParticles(Entity shooter, WeaponMuzzle muzzle, Vec3 origin, float bodyYaw, float scale)
    {
        ExternalProjectileSupport.shootParticles(shooter, muzzle, origin, bodyYaw, scale);
    }

    /**
     * Broadcasts smoke, casing ejection and, for cannons, a layered muzzle blast after a successful shot.
     * Cosmetic only. Call once per fired barrel on the server thread, independently of authored shooting particles.
     *
     * @param shooter
     *            source entity and dimension
     * @param weapon
     *            mounted gun definition, or null for a platform barrel
     * @param origin
     *            world muzzle position in blocks
     * @param direction
     *            outward barrel direction, normalized by the implementation
     * @param scale
     *            positive visual size multiplier, normally 1
     * @param heavy
     *            whether this is a cannon discharge with a bright blast
     */
    public static void firingEffects(Entity shooter, @Nullable IContentType weapon, Vec3 origin, Vec3 direction, float scale, boolean heavy)
    {
        ExternalProjectileSupport.firingEffects(shooter, weapon, origin, direction, scale, heavy);
    }

}
